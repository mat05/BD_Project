CREATE VIEW P2_LesRepresentations
AS
    SELECT noSpec, nomSpec, dateRep, promoRep, prixRep
    FROM P1_LesRepresentations join LesSpectacles using (noSPec)
    WHERE (noSpec, dateRep) not in ( SELECT DISTINCT noSpec,dateRep
                                     FROM LesTickets);

