CREATE VIEW LesReservations
AS
    SELECT noSpec, dateRep, count (noPlace,noRang) AS nbPlacesReserver
    FROM LesTickets
    GROUP BY noSpec, dateRep;

