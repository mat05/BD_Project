CREATE VIEW P2_LesSpectacles
AS
    SELECT noSpec,nomSpec,dateRep, nbPlacesReserver
    FROM LesReservations join LesSpectacles using (noSPec)
    GROUP BY noSpec, dateRep;

