CREATE VIEW P1_LesRepresentations
AS
    SELECT noSpec , dateRep, promoRep, (prixBaseSpec*(1 - promoRep)) as prixRep, count(*) as nbPlacesDispo
    FROM LesRepresentations JOIN LesSpectacles on noSpec natural left outer join
        (SELECT noSpec, noRang, noPlace, dateRep ,(prixBaseSpec * (1-promoRep)) as prixRep from LesRepresentations
          CROSS JOIN LesPlaces join LesSpectacles ON noSpec NATURAL JOIN LesZones
            where (noSpec , noRang , noPlace , dateRep) not in
                  (select noSpec, noRang,noPlace , dateRep FROM LesTickets ))
    GROUP BY nomSpec, dateRep, prixRep;

